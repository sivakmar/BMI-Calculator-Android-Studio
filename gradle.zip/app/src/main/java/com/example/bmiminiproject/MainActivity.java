package com.example.bmiminiproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText userage,userweight,userheight,userinches;
    TextView Result;
    Button ResultButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userage=(EditText)findViewById(R.id.age);
        userweight=(EditText)findViewById(R.id.weight);
        userheight=(EditText)findViewById(R.id.height);
        userinches=(EditText)findViewById(R.id.inches);
        ResultButton=(Button)findViewById(R.id.button);
        Result=(TextView)findViewById(R.id.result);

        ResultButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightstr=userweight.getText().toString();
                String heightstr=userheight.getText().toString();
                String inches=userinches.getText().toString();

                if(TextUtils.isEmpty(weightstr) || TextUtils.isEmpty(heightstr)) {
                    Result.setText("Please enter all the fields");
                    return;
                }
                float weight=Float.parseFloat(weightstr);
                float feet=Float.parseFloat(heightstr);
                float inc=Float.parseFloat(inches);

                float height2 = (float) (feet*0.3048+ inc*0.0254);

                float bmi=weight/(height2*height2);
                String bmitext=Float.toString(bmi);
                Result.setText(bmitext);
                if(bmi>24)
                    Result.setText("Overweight :"+bmi);
                else if (bmi>18)
                {
                    Result.setText("Normalweight :"+bmi);
                }
                else
                    Result.setText("Underweight :"+bmi);
            }
        });
    }
}